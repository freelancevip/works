<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>

</head>
<body>

<h1>Закон України Про об'єднання співвласників багатоквар</h1>
<p><span date-link="zu-osmd-st-1" class="open-law">ст. 1</span></p>
<p><span date-link="zu-osmd-st-2" class="open-law">ст. 2</span></p>
<p><span date-link="zu-osmd-st-3" class="open-law">ст. 3</span></p>
<p><span date-link="zu-osmd-st-4" class="open-law">ст. 4</span></p>
<p><span date-link="zu-osmd-st-5" class="open-law">ст. 5</span></p>
<p><span date-link="zu-osmd-st-6" class="open-law">ст. 6</span></p>
<p><span date-link="zu-osmd-st-7" class="open-law">ст. 7</span></p>
<p><span date-link="zu-osmd-st-8" class="open-law">ст. 8</span></p>
<p><span date-link="zu-osmd-st-9" class="open-law">ст. 9</span></p>
<p><span date-link="zu-osmd-st-10" class="open-law">ст. 10</span></p>
<p><span date-link="zu-osmd-st-11" class="open-law">ст. 11</span></p>
<p><span date-link="zu-osmd-st-12" class="open-law">ст. 12</span></p>
<p><span date-link="zu-osmd-st-13" class="open-law">ст. 13</span></p>
<p><span date-link="zu-osmd-st-14" class="open-law">ст. 14</span></p>
<p><span date-link="zu-osmd-st-15" class="open-law">ст. 15</span></p>
<p><span date-link="zu-osmd-st-16" class="open-law">ст. 16</span></p>
<p><span date-link="zu-osmd-st-17" class="open-law">ст. 17</span></p>
<p><span date-link="zu-osmd-st-18" class="open-law">ст. 18</span></p>
<p><span date-link="zu-osmd-st-19" class="open-law">ст. 19</span></p>
<p><span date-link="zu-osmd-st-20" class="open-law">ст. 20</span></p>
<p><span date-link="zu-osmd-st-21" class="open-law">ст. 21</span></p>
<p><span date-link="zu-osmd-st-22" class="open-law">ст. 22</span></p>
<p><span date-link="zu-osmd-st-23" class="open-law">ст. 23</span></p>
<p><span date-link="zu-osmd-st-24" class="open-law">ст. 24</span></p>
<p><span date-link="zu-osmd-st-25" class="open-law">ст. 25</span></p>
<p><span date-link="zu-osmd-st-26" class="open-law">ст. 26</span></p>
<p><span date-link="zu-osmd-st-27" class="open-law">ст. 27</span></p>
<p><span date-link="zu-osmd-st-28" class="open-law">ст. 28</span></p>
<p><span date-link="zu-osmd-st-29" class="open-law">ст. 29</span></p>
<p><span date-link="zu-osmd-st-30" class="open-law">ст. 30</span></p>


<h1>Закон України Про об'єднання співвласників багатоквар</h1>
<p><span date-link="zu-osmd-st-1" class="open-law">ОСМД ст. 1</span></p>
<p><span date-link="zu-osmd-st-2" class="open-law">ОСМД ст. 2</span></p>
<p><span date-link="zu-osmd-st-3" class="open-law">ОСМД ст. 3</span></p>
<p><span date-link="zu-osmd-st-4" class="open-law">ОСМД ст. 4</span></p>
<p><span date-link="zu-osmd-st-5" class="open-law">ОСМД ст. 5</span></p>

<p>. . . . . . .</p>

<p><span date-link="zu-hpk-st-1" class="open-law">ХПК ст. 1</span></p>
<p><span date-link="zu-hpk-st-2" class="open-law">ХПК ст. 2</span></p>
<p><span date-link="zu-hpk-st-2-1" class="open-law">ХПК ст. 2-1</span></p>
<p><span date-link="zu-hpk-st-3" class="open-law">ХПК ст. 3</span></p>

<p><span date-link="zu-hpk-st-4" class="open-law">ХПК ст. 4</span></p>
<p><span date-link="zu-hpk-st-4-1" class="open-law">ХПК ст. 4-1</span></p>
<p><span date-link="zu-hpk-st-4-2" class="open-law">ХПК ст. 4-2</span></p>
<p><span date-link="zu-hpk-st-4-3" class="open-law">ХПК ст. 4-3</span></p>
<p><span date-link="zu-hpk-st-4-4" class="open-law">ХПК ст. 4-4</span></p>
<p><span date-link="zu-hpk-st-4-5" class="open-law">ХПК ст. 4-5</span></p>

<p>. . . . . . .</p>

<p><span date-link="zu-osmd-st-14" class="open-law">ст. 14</span></p>
<p><span date-link="zu-osmd-st-15" class="open-law">ст. 15</span></p>
<p><span date-link="zu-osmd-st-16" class="open-law">ст. 16</span></p>
<p><span date-link="zu-osmd-st-17" class="open-law">ст. 17</span></p>
<p><span date-link="zu-osmd-st-18" class="open-law">ст. 18</span></p>
<p><span date-link="zu-osmd-st-19" class="open-law">ст. 19</span></p>
<p><span date-link="zu-osmd-st-20" class="open-law">ст. 20</span></p>
<p><span date-link="zu-osmd-st-21" class="open-law">ст. 21</span></p>
<p><span date-link="zu-osmd-st-22" class="open-law">ст. 22</span></p>
<p><span date-link="zu-osmd-st-23" class="open-law">ст. 23</span></p>
<p><span date-link="zu-osmd-st-24" class="open-law">ст. 24</span></p>
<p><span date-link="zu-osmd-st-25" class="open-law">ст. 25</span></p>
<p><span date-link="zu-osmd-st-26" class="open-law">ст. 26</span></p>
<p><span date-link="zu-osmd-st-27" class="open-law">ст. 27</span></p>
<p><span date-link="zu-osmd-st-28" class="open-law">ст. 28</span></p>
<p><span date-link="zu-osmd-st-29" class="open-law">ст. 29</span></p>
<p><span date-link="zu-osmd-st-30" class="open-law">ст. 30</span></p>


	
	<script src="//code.jquery.com/jquery-latest.js"></script>
	
	<!-- Подключение popup featherlight -->
	<link href="//cdn.rawgit.com/noelboss/featherlight/1.3.4/release/featherlight.min.css" type="text/css" rel="stylesheet" />
	<script src="//cdn.rawgit.com/noelboss/featherlight/1.3.4/release/featherlight.min.js" type="text/javascript" charset="utf-8"></script>
	<!-- / Подключение popup featherlight -->
	
	<script type="text/javascript" src="./libs/js-popup-linker.js"></script>
	
	
</body>
</html>